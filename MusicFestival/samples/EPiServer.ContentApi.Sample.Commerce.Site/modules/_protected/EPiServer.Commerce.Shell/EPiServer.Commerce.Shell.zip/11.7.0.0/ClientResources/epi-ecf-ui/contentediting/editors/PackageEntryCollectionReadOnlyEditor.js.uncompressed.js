﻿define("epi-ecf-ui/contentediting/editors/PackageEntryCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/PackageEntryCollectionReadOnlyEditorModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.packageentrycollectioneditor"
],
function (
    //dojo
    declare,
    
    // epi commerce
    ReadOnlyCollectionEditor,
    PackageEntryCollectionReadOnlyEditorModel,

    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/PackageEntryCollectionReadOnlyEditor
        // summary:
        //      Represents the Read-only editor widget for package entries.

        iconClass: "epi-iconObjectPackage",

        modelType: PackageEntryCollectionReadOnlyEditorModel,

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", res.nodatamessage);
            this.inherited(arguments);
        },
               
        changeToView: "packageview",

        buttonLabel: res.editbuttontext
    });
});