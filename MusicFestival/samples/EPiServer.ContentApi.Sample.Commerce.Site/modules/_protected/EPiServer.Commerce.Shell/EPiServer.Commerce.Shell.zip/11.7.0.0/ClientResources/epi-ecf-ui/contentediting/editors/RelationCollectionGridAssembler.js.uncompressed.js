﻿define("epi-ecf-ui/contentediting/editors/RelationCollectionGridAssembler", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/when",
    // epi
    "epi/shell/selection",
    "epi/shell/command/builder/ButtonBuilder",
    // epi-cms
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/editors/DefaultGridAssembler"

],
function (
    //dojo
    array,
    declare,
    when,
    // epi
    selection,
    ButtonBuilder,
    // epi-cms
    _ContentContextMixin,
    DefaultGridAssembler
) {
    return declare([DefaultGridAssembler, _ContentContextMixin], {
        renderActionMenu: function(item, node, commands) {
            var builder = new ButtonBuilder({ settings: { showLabel: false } });
            array.forEach(commands, function(command) {
                builder.create(command, node);
            });
        }
    });
});