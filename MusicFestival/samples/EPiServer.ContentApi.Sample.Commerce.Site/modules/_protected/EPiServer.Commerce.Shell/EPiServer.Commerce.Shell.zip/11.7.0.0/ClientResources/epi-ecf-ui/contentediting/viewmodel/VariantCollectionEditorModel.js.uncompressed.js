﻿define("epi-ecf-ui/contentediting/viewmodel/VariantCollectionEditorModel", [
    // dojo
    "dojo/_base/declare",

    // ecf
    "./VariantCollectionReadOnlyEditorModel",
    "./_RelationCollectionEditorModelMixin",

    // epi cms
    "epi-cms/dgrid/formatters",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.variantcollectioneditor"
],
function (
    //dojo
    declare,

    // ecf
    VariantCollectionReadOnlyEditorModel,
    _RelationCollectionEditorModelMixin,

    // epi cms
    formatters,

    // Resources
    resources
) {
    return declare([VariantCollectionReadOnlyEditorModel, _RelationCollectionEditorModelMixin], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/VariantCollectionEditEditorModel
        // summary:
        //      Represents the model for VariantCollectionEditor

        resources: resources,

        generateColumnsDefinition: function () {
            // summary:
            //      Generate columns definition.
            // tags:
            //      public
            return {
                contentTypeIdentifier: {
                    label: "",
                    className: "epi-columnIcon16x16",
                    formatter: function (typeIdentifier, additionalClass) {
                        return formatters.contentIcon(typeIdentifier, additionalClass);
                    }
                },
                name: {
                    label: this.resources.headings.name
                },
                code: {
                    label: this.resources.headings.code
                },
                path: {
                    label: this.resources.headings.path
                }
            };
        }
    });
});