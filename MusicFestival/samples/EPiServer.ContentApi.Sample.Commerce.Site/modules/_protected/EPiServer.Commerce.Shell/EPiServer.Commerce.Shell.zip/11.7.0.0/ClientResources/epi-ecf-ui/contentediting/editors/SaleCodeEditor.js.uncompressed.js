require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/SaleCodeEditor.html':"﻿<div class=\"epi-saleCodeEditor dijitInline\">\r\n    <div data-dojo-type=\"dijit/form/ValidationTextBox\" data-dojo-attach-point=\"textWidget\"></div>\r\n    <div data-dojo-type=\"epi-cms/contentediting/editors/SelectionEditor\" data-dojo-attach-point=\"selectWidget\"></div>\r\n</div>\r\n"}});
﻿define("epi-ecf-ui/contentediting/editors/SaleCodeEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-style",
    "dojo/keys",
// dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/ValidationTextBox",
    "dijit/focus",
// dojox
    "dojox/html/entities",
// cms
    "epi-cms/contentediting/editors/SelectionEditor",
// epi-ecf-ui
    "./_KeyboardBlurMixin",
// template
    "dojo/text!./templates/SaleCodeEditor.html"
], function (
// dojo
    declare,
    lang,
    array,
    domStyle,
    keys,
// dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    TextBox,
    focusUtil,
// dojox
    htmlEntities,
// cms
    SelectionEditor,
// epi-ecf-ui
    _KeyboardBlurMixin,
// template
    template
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _KeyboardBlurMixin], {
        // module:
        //  epi-ecf-ui/contentediting/editors/SaleCodeEditor
        // summary:
        //    Represents the widget to edit sale codes.
        // tags:
        //    public

        templateString: template,

        shouldShowDropDown: false,

        startup: function () {
            this.showDropDown(this.get("shouldShowDropDown"));
        },

        showDropDown: function (showDropDown) {
            this.set("shouldShowDropDown", showDropDown);
            domStyle.set(this.selectWidget.domNode, "display", showDropDown ? "" : "none");
            domStyle.set(this.textWidget.domNode, "display", showDropDown ? "none" : "");
            if (showDropDown){
                var value = this.get("value");
                var valueIsAnOption = array.some(this.selectWidget.get("options"), function(option){
                    return option.value === value;
                });
                if (!valueIsAnOption){
                    //if the current value is not an option, set the first option as value
                    this.set("value", this.selectWidget.get("options")[0].value);
                }
            }
        },

        _getValueAttr: function () {
            return this._getActiveWidget().get("value");
        },

        _setValueAttr: function(value){
            this.selectWidget.set("value", value);
            this.textWidget.set("value", value);
        },

        _getActiveWidget: function(){
            return this.get("shouldShowDropDown") ? this.selectWidget : this.textWidget;
        },

        _setSelectionsAttr: function (selections) {
            this.selectWidget.set("selections", selections);
        },

        focus: function(){
            this._getActiveWidget().focus();
        }
    });
});
